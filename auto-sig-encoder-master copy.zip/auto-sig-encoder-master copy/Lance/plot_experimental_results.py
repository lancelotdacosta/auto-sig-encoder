"""
Script generating plots for handwritten number data set: signature and log sig terms
"""


# Build-ins import
import os, sys, inspect
import pandas as pd

# Home-brew import
import iisignature
from pprint import pprint
import numpy as np
from matplotlib import pyplot as plt
# import seaborn as sns
# sns.set(style="darkgrid")

'''
Plotting/saving experimental results
'''

def save_experimental_results(sig_data_test, decoded_data, plot_dir, depth, comp, ex, epochs, method, d=-1):
    plt.clf()
    error = decoded_data - sig_data_test #reconstruction error
    l = sig_data_test.shape[1] #number of elements in logsig
    for o in range(sig_data_test.shape[0]):
        plt.ion() #turn interactive mode on

        plt.subplot(3, 1, 1)
        plt.plot(range(l), sig_data_test[o,])
        if d == -1:
            plt.title(f"{method}: depth={depth}, compression= *{comp}, epochs={epochs}")
        else:
            plt.title(f"Digit={d}; {method}: depth={depth}, compression= *{comp}, epochs={epochs}")
        plt.ylabel(f'{method}')

        plt.subplot(3, 1, 2)
        plt.plot(range(l), decoded_data[o,])                                                                           #change
        plt.ylabel('Reconstruction')

        plt.subplot(3, 1, 3)
        plt.plot(range(l), error[o,])                                                                           #change
        plt.xlabel('Indices in lexicographical order')
        plt.ylabel('Error')

        plt.show()

    if d == -1: # d is an optional digit indicating the time series are a certain digit
        plt.savefig(plot_dir + f"experiment_{ex}.png")
    else:
        plt.savefig(plot_dir + f"experiment_{ex}_digit_{d}.png")

    print("File saved in ex: " + f"{ex}")



'''
Plotting results by digits
'''

def digi_plot(max, data, method, auto_encoder, n_o, depth, plot_dir, comp, ex, epochs):

    #loop over digits. plot n_0 digits and their reconstruction
    for d in range(10):
        data_digit = data.test_X_ordered[d][0:n_o] #selects first n_0 observations of the digit d

        #get sig or logsig
        if method == "logsig":
            dim_path = np.shape(data_digit[0][0])[0]  # gets dimension of path
            s = iisignature.prepare(dim_path, depth)  # prepare to take logsignature
            sig_data_test = np.float32(iisignature.logsig(data_digit, s))
        elif method == "sig":
            sig_data_test = np.float32(iisignature.sig(data_digit, depth))

        #normalise
        sig_data_test = sig_data_test/max

        #encode/decode
        encoded_data = auto_encoder.encoder.predict(sig_data_test)  # encode test data
        decoded_data = auto_encoder.decoder.predict(encoded_data)  # decode test data

        #plot digit
        save_experimental_results(sig_data_test[0:n_o, ], decoded_data[0:n_o, ], plot_dir, depth, comp, ex, epochs,
                                  method, d)

