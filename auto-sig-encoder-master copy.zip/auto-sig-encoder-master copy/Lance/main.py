import os, sys, inspect, random
import iisignature
import matplotlib.pyplot as plt
import numpy as np
import tensorflow as tf
import time #to do pauses in scripts
from scipy import stats

'''
Import dependencies
'''

# changing path to import modules
current_dir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
try:
    c_dir = current_dir
    from plot_experimental_results import save_experimental_results, digi_plot
except:
    c_dir = current_dir + "/venv/auto-sig-encoder-master/"
    sys.path.insert(0, c_dir)
    from Lance.plot_experimental_results import save_experimental_results

try:
    package_dir = current_dir.replace("/Lance", "")
    #package_dir = package_dir + "/venv/auto-sig-encoder-master"                                                             #To be removed when running
    sys.path.insert(0, package_dir)

    #import autoencoder
    from src.base.auto_encoders import auto_encoder_shallow
    #load data class
    from src.data.data_preparation import data_set_1

    # dataset location
    dataset_dir = package_dir + "/src/data/raw_data/handwritten/"

    # create dataset
    data = data_set_1(dataset_dir)
except:
    package_dir = current_dir.replace("/Lance", "")
    package_dir = package_dir + "/venv/auto-sig-encoder-master"                                                             #To be removed when running
    sys.path.insert(0, package_dir)

    # import autoencoder
    from src.base.auto_encoders import auto_encoder_shallow
    # load data class
    from src.data.data_preparation import data_set_1

    # dataset location
    dataset_dir = package_dir + "/src/data/raw_data/handwritten/"

    # create dataset
    data = data_set_1(dataset_dir)



#print dataset
#print(data.training_X_ordered)


'''
SIG-LOGSIG
'''

def sig(data, depth=5, comp =1/2, epochs =1, batch_size = 60, method = "logsig"):

    #Getting sig or logsig depending on chosen method
    if method == "logsig":
        dim_path = np.shape(data.training_X[0][0])[0]  # gets dimension of path
        s = iisignature.prepare(dim_path, depth)  # prepare to take logsignature
        sig_data_train = np.float32(iisignature.logsig(data.training_X, s))  # computes logsig up to depth 5
        sig_data_test = np.float32(iisignature.logsig(data.test_X, s))
    elif method == "sig":
        sig_data_train = np.float32(iisignature.sig(data.training_X, depth))  # computes logsig up to depth 5
        sig_data_test = np.float32(iisignature.sig(data.test_X, depth))

    #normalising the output to one
    max = np.max([np.abs(sig_data_train).max(), np.abs(sig_data_test).max()])
    sig_data_train = sig_data_train/max
    sig_data_test = sig_data_test/max

    # length of sig/logsig vector #to determine autoencoder structure
    shape_single_data_point = sig_data_train[0].shape

    #encode to comp of original dimension
    encoding_dim = int(comp*shape_single_data_point[0]) #dimension of hidden layer

    # 2. Setting and training auto-encoders
    auto_encoder = auto_encoder_shallow(encoding_dim=encoding_dim, input_shape=shape_single_data_point)
    auto_encoder.train(training_set=sig_data_train, test_set=sig_data_test, epochs=epochs, batch_size=batch_size)

    # 3. Encode + decode test set
    encoded_data = auto_encoder.encoder.predict(sig_data_test) #encode test data
    decoded_data = auto_encoder.decoder.predict(encoded_data) #decode test data

    return sig_data_test, decoded_data, auto_encoder, max

'''
To get reproducible results
'''

# Seed value
# Apparently you may use different seed values at each stage
seed_value= 1

# 1. Set `PYTHONHASHSEED` environment variable at a fixed value
os.environ['PYTHONHASHSEED']=str(seed_value)

# 2. Set `python` built-in pseudo-random generator at a fixed value
random.seed(seed_value)

# 3. Set `numpy` pseudo-random generator at a fixed value
np.random.seed(seed_value)

# 4. Set `tensorflow` pseudo-random generator at a fixed value
#tf.set_random_seed(seed_value) 3bugs for some reason

# 5. Configure a new global `tensorflow` session
#from keras import backend as K
#session_conf = tf.ConfigProto(intra_op_parallelism_threads=1, inter_op_parallelism_threads=1)
#sess = tf.Session(graph=tf.get_default_graph(), config=session_conf)
#K.set_session(sess)

'''
MAIN
'''

#experiment number
ex = 2
#sig or logsig?
method="logsig"
#depth of sig/logsig
depth = 5
#compression factor
comp = 0.25
# number of epochs
epochs = 40
# batch size
batch_size = 10

# run sig
sig_data_test, decoded_data, auto_encoder, max = sig(data=data, depth=depth, comp=comp, epochs=epochs, method=method, batch_size=batch_size)

# Compare sig_data_test vs encoded_data
# stats.describe(sig_data_test)
# stats.describe(decoded_data)

'''
Plotting/Saving results
'''

#directory to plot results
c_dir = c_dir.replace("Lance", "")
plot_dir = c_dir + "Lance/experiments/"
print(plot_dir)

#number of observations to save
n_o = 5

# plot first values of the data set and their reconstruction + save
save_experimental_results(sig_data_test[0:n_o,], decoded_data[0:n_o,], plot_dir, depth, comp, ex, epochs, method)

#plot results by digit
digi_plot(max, data, method, auto_encoder, n_o, depth, plot_dir, comp, ex, epochs)





