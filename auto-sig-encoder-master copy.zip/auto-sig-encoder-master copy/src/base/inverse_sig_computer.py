# Build-ins import
#

# Homebrew
#

class inverse_sig_computer:
    """
    Takes as input sig features up to index k
    """
    def __init__(self):
        # self.truncation_index = truncation_index
        # etc...
        raise NotImplementedError

# testing unit
if __name__ == "__main__":
    pass