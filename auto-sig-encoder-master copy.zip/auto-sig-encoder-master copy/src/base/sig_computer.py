# Build-ins import
#

# Homebrew
import iisignature

class sig_computer:
    """
    Takes as input stream of data and output troncated sig up to index k
    """
    def __init__(self):
        # self.truncation_index = truncation_index
        # etc...
        raise NotImplementedError

# testing unit
if __name__ == "__main__":
    pass