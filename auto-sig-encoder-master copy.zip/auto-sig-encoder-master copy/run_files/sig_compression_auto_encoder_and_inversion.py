"""
Script orchestrating running of sig compression of data, another compression using a AE and its inversion using algo in
"Inverting the signature of a path", https://arxiv.org/abs/1406.7833
"""

# build-ins import
#

# home-brew import
#

raise NotImplementedError